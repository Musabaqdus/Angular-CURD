import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  readonly url = "http://localhost:3000/";

  constructor(private HTTP: HttpClient) { }

  AddUpdateUser(Users: any, type: string): Observable<any> { 
    if (type === 'Add') {
       return this.HTTP.post(this.url + "Users", Users);
    } else {
       return this.HTTP.put(this.url + "Users/" + Users.id, Users);
    }
 }

  GetAllUsers(): Observable<any> { 
    return this.HTTP.get(this.url + "Users");
  }

  DeleteUserByID(ID: any): Observable<any> { 
    return this.HTTP.delete<any>(this.url + "Users/" + ID);
  }
  GetUserByID(ID: any): Observable<any> { 
    return this.HTTP.get<any>(this.url + "Users/" + ID);
  }
}




