import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from '../common.service';
declare var $: any
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users: any;
  userForm: FormGroup;

  constructor(private fb: FormBuilder, private service: CommonService) {
    this.userForm = this.fb.group({
      'Name': [""],
      'Email': [""],
      'Age': [""],
      'Number': [""],
    });
  }

  ngOnInit(): void {
    this.GetAllUsers();
  }

  SubmitForm() {
    const type = this.userForm.value.id == null ? 'Add' : 'Update';
    console.log(this.userForm.value);
    this.service.AddUpdateUser(this.userForm.value, type).subscribe(Data => {
      if (type === 'Add') {
        alert("Added");
      } else {
        alert("Updated");
      }
      this.userForm.reset();
      this.GetAllUsers();
      console.log(Data);
    });
  }
  

  GetAllUsers() {
    this.service.GetAllUsers().subscribe(Data => {
      console.log('users', Data);
      this.users = Data;
    });
  }

  DeleteUserByID(ID: any) {
    this.service.DeleteUserByID(ID).subscribe(() => {
      alert("User Deleted!");
      this.GetAllUsers();
    });
  }
  GetUserByID(ID: any) {
    this.service.GetUserByID(ID).subscribe( Data=> {
     alert("Got Updates!")
      console.log("user details", Data)
      
        $("#home").addClass('show' );
        $("#home").addClass('active' );
        $("#profile").removeClass('show');
        $("#profile").removeClass('active');
      
      
      this.userForm.patchValue({
        Name: Data.Name,
        Email: Data.Email,
        Age: Data.Age,
        Number: Data.Number
      })
    });
  }
}
